Quick Note About These Exercise Files
======================================

This course is using a tool, like Vagrant or Terraform, that will write data
into this directory.

You'll need this Exercise Files folder for the next few videos.

If you navigate away from this folder, some commands, like "vagrant up" or "terraform plan" will not work.

If that happens, simply `cd` your way back into the folder.

Have fun!
